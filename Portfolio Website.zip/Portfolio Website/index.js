const tab = document.querySelector(".tabs");
const gallery = document.querySelectorAll(".images");

tab.addEventListener("click", (event)=> {
 
     console.log(event.target.dataset.category1);  //all, animal, bird , nature  = attribute value
     if(event.target.dataset.category1 !== undefined){
      filterSearch(event.target.dataset.category1);
     }
     
})


 const filterSearch = (value)=> {
    gallery.forEach( (curElem)=> {
            console.log(curElem.dataset.category1);
             
            if(curElem.dataset.category1 === value){
                curElem.style.display = "block";
            }
            else if (value === "all"){
              curElem.style.display = "block";
            }
            else{
              curElem.style.display = "none";
            }
    })
 }